# Joypriya R — Joypriya R — Personal Portfolio Website

A responsive student portfolio built with **HTML, CSS, and vanilla JavaScript only**. It uses no React, Bootstrap, or other framework.

## Files included
- `index.html` — page content and structure
- `style.css` — responsive styling and light/dark theme
- `script.js` — mobile menu, theme toggle, project filters, contact-form validation, navigation highlighting, and footer year
- `images/projects/` — three local SVG project-preview illustrations
- `images/profile.jpg (your profile photo is already included)` — add your own profile photo here

## Add your profile photo
1. Copy your photo into the `images` folder.
2. Rename it exactly `profile.jpg`.
3. Keep it directly inside `images` (not inside `images/projects`).
4. Refresh the website. A clear portrait JPG works best.

## LinkedIn link
Your exact LinkedIn profile URL was not supplied, so this project does not invent one. When you have it, open `script.js` and replace the empty value on the first line with your real profile URL, for example:

```js
const LINKEDIN_PROFILE_URL = "https://www.linkedin.com/in/your-actual-profile/";
```

Use your real URL, not the example. Save the file and refresh the page.

## Projects shown
1. **AI-Powered Land Data & Policy Portal** — an SIH concept for land datasets, GIS, and policy discovery.
2. **Guess the Number Game** — a beginner browser-game project using HTML and JavaScript.
3. **Basic JavaScript Calculator** — a practice project for arithmetic logic and UI interactions.

The project visuals are locally included illustrative previews, not screenshots of deployed projects. Only keep project descriptions that accurately represent your work. Add real GitHub/live-demo links only after testing them.

## Contact details
The email link is set to `joypriyaranjithkumar@gmail.com`. The contact form is a demo: it validates entries but does not send or store messages.

## Run in VS Code
1. Open this folder in VS Code.
2. Open `index.html` in your browser, or right-click it and select **Open with Live Server** if installed.
3. Save edits with `Ctrl + S`.

## Publish using GitHub Pages (free)
1. Sign in at https://github.com/ and select **+ → New repository**.
2. Name it `joypriya-portfolio` and choose **Public**.
3. Create the repository.
4. Select **Add file → Upload files**. Upload `index.html`, `style.css`, `script.js`, and the complete `images` folder.
5. Click **Commit changes**.
6. Open **Settings → Pages**. Under **Build and deployment**, choose **Deploy from a branch**.
7. Choose branch `main` and folder `/(root)`, then click **Save**.
8. Wait a few minutes and copy the exact URL GitHub Pages displays. It usually resembles `https://YOUR-GITHUB-USERNAME.github.io/joypriya-portfolio/`. Do not guess the URL.
9. Open the live URL and test the photo, navigation, theme, filters, and email link.

## College submission checklist
- [ ] Add your real profile photo as `images/profile.jpg (your profile photo is already included)`
- [ ] Add your real LinkedIn profile URL in `script.js`
- [ ] Review project descriptions and skills for accuracy
- [ ] Upload all files to a **public** GitHub repository
- [ ] Enable GitHub Pages and verify the live URL
- [ ] Submit the repository URL and live website URL in the college form
- [ ] Obtain the trainer's physical signature
- [ ] Obtain Technical Head approval/signature and seal, as required


Personal details configured:
- Name: Joypriya R
- Email: joypriyaranjithkumar@gmail.com
- LinkedIn: https://www.linkedin.com/in/joypriya-r-3a3b11400/
- Profile photo: images/profile.jpg
